from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import socket

HOST = '187.67.138.176'
PORT = 8003
ADDR = (HOST, PORT)
USERNAME = 'formulario'
PASSWORD = 'Kiuj9d87Qbbn177'

